// let server_input = document.getElementById('server_input')

// server_input.addEventListener('keydown',function(e) {
//     if(e.key == 'Enter'){
//         sendMessage(e.target.value)
//         e.target.value = ''
//     }
// })