function routeMercado(){
    return /*html*/`
        <div>MERCADO</div>
    `
}