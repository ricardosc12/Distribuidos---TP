Links para o download da aplicação cliente:

LINUX: 
(1) Google Drive - https://drive.google.com/file/d/1LBFvP_mp6hBb8MjR_dIUtaOTZn-oEqaL/view?usp=sharing

(1) One Drive - https://1drv.ms/u/s!AjQVv0fF2WQo2BbfEl6isni6BpK6?e=FCgp8l

A pasta Interface contem os arquivos brutos de codificação, não sendo possível rodá-la a partir destes códigos.

Para instalar a aplicação:

(2) sudo dpkg -i infinity-deck_web.deb

Para iniciar o servidor

Pasta Server
(3) python3 server.py  - Iniciará no host 127.0.0.1 e porta 23123  // o mesmo que a aplicação

Para iniciar a aplicação

(4) infinity-deck --no-sandbox





